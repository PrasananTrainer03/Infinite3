package com.java.testing;

public enum Gender {
	MALE, FEMALE
}
