package com.spr.mvc.beans;

public enum Gender {

	MALE, FEMALE
}
