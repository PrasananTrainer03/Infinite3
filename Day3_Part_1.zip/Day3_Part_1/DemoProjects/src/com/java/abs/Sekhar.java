package com.java.abs;

public class Sekhar extends Training {

	@Override
	void name() {
		System.out.println("Name is Sekhar...");
	}

	@Override
	void email() {
		System.out.println("Email is sekhar@gmail.com");
	}

}
