package com.java.abs1;

public class Omkar extends Flight {

	@Override
	void ticket() {
		System.out.println("Hi I am Omkar having Business Class Ticket...");
	}

	@Override
	void idProof() {
		System.out.println("Hi I am Omkar have Passport as Id Proof");
	}

}
