package com.java.demo;

public class Quiz1 {

	public static void main(String[] args) {
		String s1="Hello";
		s1.concat(" Word");
		String s2=s1.concat(" World");
		System.out.println(s2);
		System.out.println(s1);
	}
}
