package com.java.abs1;

public class Swathi extends Flight {

	@Override
	void ticket() {
		System.out.println("Hi I am Swathi...having Executive Class Ticket...");
	}

	@Override
	void idProof() {
		System.out.println("Hi I am Swati voter card as id proof...");
	}

	
}
