package com.java.intf;

public class MultiInh {

}
