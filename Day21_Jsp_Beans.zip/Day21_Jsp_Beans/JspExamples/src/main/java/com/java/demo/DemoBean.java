package com.java.demo;

public class DemoBean {

	private String greeting = "Good Morning...";

	public String getGreeting() {
		return greeting;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}
	
	
}
