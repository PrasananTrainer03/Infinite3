package com.java.rest;

public enum LeaveType {

	EL
}
