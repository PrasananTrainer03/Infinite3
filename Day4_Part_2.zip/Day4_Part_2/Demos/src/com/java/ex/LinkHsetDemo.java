package com.java.ex;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkHsetDemo {

	public static void main(String[] args) {
		Set names = new LinkedHashSet();
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");

		for (Object ob : names) {
			System.out.println(ob);
		}
	}
}
