package com.java.infinite;


public class AbsDemo {

}
