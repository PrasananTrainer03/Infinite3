package com.java.abs;

public class Shahida extends Training {

	@Override
	void name() {
		System.out.println("Name is Shahida...");
	}

	@Override
	void email() {
		System.out.println("Email is shahida@gmail.com");
	}

}
