package com.java.spr;

public interface Hello {
	
	String salution(String user);
	String resolve(String user);
}
