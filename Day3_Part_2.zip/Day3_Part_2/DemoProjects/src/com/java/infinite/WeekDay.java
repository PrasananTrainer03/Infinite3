package com.java.infinite;

public enum WeekDay {

	SUNDAY, 
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY
}
