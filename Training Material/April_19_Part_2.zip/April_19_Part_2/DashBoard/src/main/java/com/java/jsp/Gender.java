package com.java.jsp;

public enum Gender {
	MALE, FEMALE
}
