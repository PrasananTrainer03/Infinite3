import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-wallets',
  templateUrl: './customer-wallets.component.html',
  styleUrls: ['./customer-wallets.component.css']
})
export class CustomerWalletsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
