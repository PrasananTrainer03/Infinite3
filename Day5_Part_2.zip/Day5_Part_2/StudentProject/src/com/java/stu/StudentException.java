package com.java.stu;

public class StudentException extends Exception {

	StudentException() {}
	
	StudentException(String error) {
		super(error);
	}
}
