package com.java.abs2;

public abstract class Animal {
	abstract void name();
	abstract void type();
}
