package com.java.intf;

public class Sirisha implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Sirisha...");
	}

	@Override
	public void email() {
		System.out.println("Email is sirisha@gmail.com");
	}

}
