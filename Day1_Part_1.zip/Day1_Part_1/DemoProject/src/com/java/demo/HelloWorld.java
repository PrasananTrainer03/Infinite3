package com.java.demo;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Welcome to Java Programming...");
	}
}
