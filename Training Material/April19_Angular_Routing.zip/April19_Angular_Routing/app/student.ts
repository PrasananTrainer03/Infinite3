export class Student {

    constructor(public sno: number, public name : string,public city : string,
        public cgp : number)
    {

    }
}

