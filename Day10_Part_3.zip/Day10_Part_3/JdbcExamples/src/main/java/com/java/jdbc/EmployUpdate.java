package com.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class EmployUpdate {

	public static void main(String[] args) {
		int empno,basic;
		String name,dept,desig,gender;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employ No    ");
		empno = sc.nextInt();
		System.out.println("Enter Employ Name   ");
		name=sc.next();
		System.out.println("Gender  (MALE or FEMALE) ");
		gender=sc.next().toUpperCase();
		System.out.println("Enter Department   ");
		dept=sc.next();
		System.out.println("Enter Designation   ");
		desig=sc.next();
		System.out.println("Enter Basic   ");
		basic=sc.nextInt();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/infinitepractice", 
					"root", "root");
			String cmd = "Update Employ set Name=?, Gender=?, Dept=?, Desig=?, Basic=? "
					+ " Where Empno=?";
			PreparedStatement pst = con.prepareStatement(cmd);
			pst.setString(1, name);
			pst.setString(2, gender);
			pst.setString(3, dept);
			pst.setString(4, desig);
			pst.setInt(5, basic);
			pst.setInt(6, empno);
			pst.executeUpdate();
			System.out.println("*** Record Updated ***");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
