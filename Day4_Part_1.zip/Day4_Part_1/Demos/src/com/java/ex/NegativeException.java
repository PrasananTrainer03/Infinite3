package com.java.ex;

public class NegativeException extends Exception {

	public NegativeException() {
		// TODO Auto-generated constructor stub
	}
	
	public NegativeException(String error) {
		super(error);
	}
}
