package com.java.rest;

public enum LeaveStatus {

	PENDING, APPROVED, DENIED
}
