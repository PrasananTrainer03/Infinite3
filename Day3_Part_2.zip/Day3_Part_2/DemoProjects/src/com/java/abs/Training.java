package com.java.abs;

public abstract class Training {
	abstract void name();
	abstract void email();
}
