package com.java.intf;

public class Arjun implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Arjun...");
	}

	@Override
	public void email() {
		System.out.println("Email is Arjun@gmail.com");
	}

}
