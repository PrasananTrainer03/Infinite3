package com.java.ex;

import java.util.Date;

public class DateEx {
	public static void main(String[] args) {
		Date obj = new Date();
		System.out.println(obj);
	}
}
