
public class StrDemo {

	public static void main(String[] args) {
		String s1="Shahida",s2="Harish",s3="Shahida";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
	}
}
