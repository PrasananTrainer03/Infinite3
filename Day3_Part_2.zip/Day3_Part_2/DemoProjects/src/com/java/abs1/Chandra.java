package com.java.abs1;

public class Chandra extends Flight {

	@Override
	void ticket() {
		System.out.println("Hi I am Chandra having economy class ticket...");
	}

	@Override
	void idProof() {
		System.out.println("Hi I am Chandra having Aadhar as Id Proof");
	}

}
