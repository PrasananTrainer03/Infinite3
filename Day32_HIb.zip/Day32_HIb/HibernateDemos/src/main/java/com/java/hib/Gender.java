package com.java.hib;

public enum Gender {
	MALE, FEMALE
}
