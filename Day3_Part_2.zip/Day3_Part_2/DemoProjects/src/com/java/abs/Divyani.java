package com.java.abs;

public class Divyani extends Training {

	@Override
	void name() {
		System.out.println("Name is Divyani...");
	}

	@Override
	void email() {
		System.out.println("Email is divyani@gmail.com");
	}

	
}
