package com.java.ex;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		Set names = new HashSet();
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Rohit");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");
		names.add("Abhishek");
		names.add("Sekhar");
		names.add("Dinesh");
		names.add("Kavyasri");
		names.add("Sirisha");

		for (Object ob : names) {
			System.out.println(ob);
		}
	}
}
