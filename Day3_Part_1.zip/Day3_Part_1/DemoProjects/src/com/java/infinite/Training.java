package com.java.infinite;

public abstract class Training {

	abstract void name();
	abstract void email();
}
