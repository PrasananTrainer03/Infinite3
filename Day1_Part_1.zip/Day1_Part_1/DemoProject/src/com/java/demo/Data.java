package com.java.demo;

class Demo {
	
	public void basin() {
		System.out.println("Hi I am Basin Kumar...");
	}
	
	void dinesh() {
		System.out.println("Hi I am Dinesh...");
	}
	
	private void shahida() {
		System.out.println("Hi I am Shahida...");
	}
}
public class Data {
	public static void main(String[] args) {
		Demo obj = new Demo();
		obj.basin();
		obj.dinesh();
	}
}
