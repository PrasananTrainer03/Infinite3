package com.java.abs1;

public abstract class Flight {

	abstract void ticket();
	abstract void idProof();
}
