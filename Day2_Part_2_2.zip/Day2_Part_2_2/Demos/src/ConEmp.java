
public class ConEmp {

	public static void main(String[] args) {
		Employ emp1 = new Employ();
		System.out.println(emp1);
		Employ emp2 = new Employ(3, "Sumanth", 99345);
		System.out.println(emp2);
	}
}
