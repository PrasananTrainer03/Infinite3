package com.java.spr;

public interface Name {

	String fullName();
}
