package com.java.infinite;

public enum LeaveStatus {

	ACCEPTED, REJECTD, PENDING
}
