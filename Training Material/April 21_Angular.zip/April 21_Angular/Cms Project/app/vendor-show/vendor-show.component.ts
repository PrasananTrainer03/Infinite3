import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-show',
  templateUrl: './vendor-show.component.html',
  styleUrls: ['./vendor-show.component.css']
})
export class VendorShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
