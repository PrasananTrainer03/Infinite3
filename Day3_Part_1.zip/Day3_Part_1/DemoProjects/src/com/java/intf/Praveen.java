package com.java.intf;

public class Praveen implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Praveen...");
	}

	@Override
	public void email() {
		System.out.println("Email is praveen@gmail.com");
	}

}
