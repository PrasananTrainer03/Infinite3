package com.java.spr;

public interface Company {
	
	String showCompany(String name);
	String showBranch(String name);
}
