package com.java.infinite;

public enum LeaveType {
	EL,
	PL,
	ML
}
