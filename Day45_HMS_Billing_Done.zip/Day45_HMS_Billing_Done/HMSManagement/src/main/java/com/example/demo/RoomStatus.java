package com.example.demo;

public enum RoomStatus {

	AVAILABLE, BOOKED
}
