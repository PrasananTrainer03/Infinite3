package com.java.project;

public enum Gender {

	MALE, FEMALE
}
