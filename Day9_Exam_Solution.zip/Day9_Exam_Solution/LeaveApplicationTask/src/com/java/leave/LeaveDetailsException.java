package com.java.leave;

public class LeaveDetailsException extends Exception {

	public LeaveDetailsException() {

	}
	
	public LeaveDetailsException(String error) {
		super(error);
	}
}
